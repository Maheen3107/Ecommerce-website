/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./Views/**/*.{cshtml,razor}", "wwwroot/js/**/*.js"],
    theme: {
        extend: {},
    },
    plugins: [],
}

