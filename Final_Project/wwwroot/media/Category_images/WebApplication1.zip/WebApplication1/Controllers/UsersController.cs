﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class UsersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        
        public ViewResult Register()
        {
            bool isUserInfo = HttpContext.Request.Cookies.ContainsKey("UserInfo");

            string Name = String.Empty;
            string Email = String.Empty;
            string Password = String.Empty;
            if (isUserInfo)
            {
                string userData = HttpContext.Request.Cookies["UserInfo"];
                string[] info = userData.Split('|');
                Name = info[0];
                Email = info[1];
                Password = info[2];
            }
            var UserData = new { Name = Name, Email = Email, Password = Password };

            return View(UserData);
        }

        [HttpPost]
        public IActionResult Register(Users User)
        {
            Guid guid = Guid.NewGuid();
            string id = guid.ToString();
            Users user = new Users { Id = id, Name = User.Name, Email = User.Email, Password = User.Password };
            UsersRepository repo = new UsersRepository();
            bool isUserRegistered = repo.RegisterUser(user);

            string userData = $"{User.Name}|{User.Email}|{User.Password}";
            if (isUserRegistered)
            {
                HttpContext.Response.Cookies.Append("UserInfo", userData);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                Console.WriteLine("Something went wrong!!!");
            }
            return View();
        }
        
    }
}
