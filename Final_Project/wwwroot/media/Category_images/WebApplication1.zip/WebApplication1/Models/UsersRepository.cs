﻿using Microsoft.Data.SqlClient;
namespace WebApplication1.Models
{
    public class UsersRepository
    {
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=WebDB;Integrated Security=True";
        public bool RegisterUser(Users user)
        {
            // Checking whether user has provided all the fields
            if(user.Id == null || user.Name == null || user.Email == null || user.Password == null)
            {
                return false;
            }

            // Checking whether the email is unique or not
            SqlConnection connect = new SqlConnection(connectionString);
            connect.Open();
            string select = "select * from Users where Email=@Email";
            SqlCommand selectCommand = new SqlCommand(select, connect);
            selectCommand.Parameters.AddWithValue("@Email", user.Email);

            SqlDataReader reader = selectCommand.ExecuteReader();
            if(reader.HasRows)
            {
                return false;
            }
            connect.Close();

            // Registering the user
            connect.Open();
            bool result = false;
            try
            {
                string query = "insert into Users Values(@Id, @Name, @Email, @Password)";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@Id", user.Id);
                cmd.Parameters.AddWithValue("@Name", user.Name);
                cmd.Parameters.AddWithValue("@Email", user.Email);
                // Hashing the password
                cmd.Parameters.AddWithValue("@Password", user.Password);

                int count = cmd.ExecuteNonQuery();
                result = true;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                result = false;
            }
            connect.Close();
            return result;
        }
    }
}
